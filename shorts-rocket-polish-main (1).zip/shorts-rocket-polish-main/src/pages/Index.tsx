import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Zap,
  TrendingUp,
  Lightbulb,
  Flame,
  Eye,
  Clock,
  Target,
  ArrowRight,
  Play,
  Star,
} from "lucide-react";

const PAYPAL_LINK = "https://www.paypal.me/OskarMiler/10PLN";

const benefits = [
  { icon: Eye, title: "PAMIETAJ O PODANIU EMAIL PRZY PŁATNOŚCI", desc: "Pomysły dopasowane do algorytmu YouTube Shorts" },
  { icon: Eye, title: "Więcej wyświetleń", desc: "Pomysły dopasowane do algorytmu YouTube Shorts" },
  { icon: TrendingUp, title: "Szybszy wzrost kanału", desc: "Regularnie publikuj i buduj widownię" },
  { icon: Lightbulb, title: "Gotowe do użycia", desc: "Nie musisz wymyślać – wystarczy nagrywać" },
  { icon: Flame, title: "Potencjał viralowy", desc: "Tematy, które przyciągają uwagę i angażują" },
  { icon: Clock, title: "Oszczędność czasu", desc: "Koniec z godzinami szukania inspiracji" },
  { icon: Target, title: "Dla każdej niszy", desc: "75 000 pomysłów obejmujących setki kategorii" },
];

const faqs = [
  {
    q: "Czy te pomysły pasują do mojej niszy?",
    a: "Tak! Pakiet obejmuje setki kategorii – od lifestyle, przez gaming, edukację, finanse, po rozrywkę. Znajdziesz pomysły dopasowane do niemal każdego kanału.",
  },
  {
    q: "W jakim formacie otrzymam produkt?",
    a: "Produkt jest w formie cyfrowej – otrzymasz plik do pobrania natychmiast po zakupie.",
  },
  {
    q: "Czy mogę użyć tych pomysłów na TikToku lub Reels?",
    a: "Oczywiście! Pomysły świetnie sprawdzą się na YouTube Shorts, TikToku, Instagram Reels i każdej platformie z krótkimi filmikami.",
  },
  {
    q: "Jak szybko otrzymam dostęp?",
    a: "Od razu po zaksięgowaniu płatności PayPal zostaniesz przekierowany na stronę z linkiem do pobrania.",
  },
];

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-primary/5" />
        <div className="relative mx-auto max-w-5xl px-4 pb-16 pt-20 text-center sm:px-6 sm:pb-24 sm:pt-32">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/5 px-4 py-1.5 text-sm font-medium text-primary">
            <Play className="h-3.5 w-3.5" />
            YouTube Shorts
          </div>
          <h1 className="mx-auto max-w-3xl text-4xl font-bold leading-tight tracking-tight text-foreground sm:text-5xl lg:text-6xl">
            75 000 pomysłów na
            <span className="text-primary"> viralowe Shorts</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground sm:text-xl">
            Przestań tracić czas na wymyślanie tematów. Otrzymaj gotową bazę pomysłów, które
            przyciągają wyświetlenia i budują Twój kanał – dzień po dniu.
          </p>
          <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
            <Button size="lg" className="gap-2 px-8 text-base font-semibold shadow-lg shadow-primary/25" asChild>
              <a href={PAYPAL_LINK}>
                Kup teraz – 10 zł
                <ArrowRight className="h-4 w-4" />
              </a>
            </Button>
            <p className="text-sm text-muted-foreground">Jednorazowa płatność · Natychmiastowy dostęp</p>
          </div>
        </div>
      </header>

      {/* Benefits */}
      <section className="mx-auto max-w-5xl px-4 py-16 sm:px-6 sm:py-24">
        <h2 className="mb-4 text-center text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
          Dlaczego warto?
        </h2>
        <p className="mx-auto mb-12 max-w-2xl text-center text-muted-foreground">
          Wszystko, czego potrzebujesz, aby Twój kanał rósł szybciej niż kiedykolwiek.
        </p>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {benefits.map((b) => (
            <Card key={b.title} className="border-border/50 p-6 transition-shadow hover:shadow-md">
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                <b.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mb-1 text-lg font-semibold text-foreground">{b.title}</h3>
              <p className="text-sm text-muted-foreground">{b.desc}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* Product mockup */}
      <section className="bg-secondary/40 py-16 sm:py-24">
        <div className="mx-auto max-w-5xl px-4 sm:px-6">
          <div className="flex flex-col items-center gap-10 lg:flex-row lg:gap-16">
            {/* Mockup visual */}
            <div className="flex w-full max-w-sm flex-col items-center lg:w-1/2">
              <div className="relative w-full">
                <div className="aspect-[4/5] w-full rounded-2xl border border-border bg-gradient-to-br from-primary/10 via-card to-primary/5 p-8 shadow-xl">
                  <div className="flex h-full flex-col items-center justify-center text-center">
                    <div className="mb-4 rounded-full bg-primary/10 p-4">
                      <Zap className="h-10 w-10 text-primary" />
                    </div>
                    <p className="text-2xl font-bold text-foreground">75 000</p>
                    <p className="text-sm font-medium text-muted-foreground">pomysłów na Shorts</p>
                    <div className="mt-6 space-y-2">
                      {["YouTube Shorts", "TikTok", "Instagram Reels"].map((p) => (
                        <div key={p} className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Star className="h-3.5 w-3.5 text-primary" />
                          {p}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* Text */}
            <div className="lg:w-1/2">
              <h2 className="mb-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                Twoja skarbnica pomysłów
              </h2>
              <p className="mb-6 text-muted-foreground">
                75 000 starannie opracowanych pomysłów na krótkie filmy. Każdy temat jest
                zaprojektowany tak, aby przyciągać uwagę i generować wyświetlenia. Wystarczy
                wybrać pomysł, nagrać i opublikować.
              </p>
              <ul className="space-y-3">
                {[
                  "Setki kategorii tematycznych",
                  "Gotowe do natychmiastowego użycia",
                  "Aktualizowane pod trendy 2025",
                  "Kompatybilne ze wszystkimi platformami",
                ].map((item) => (
                  <li key={item} className="flex items-center gap-3 text-foreground">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10">
                      <ArrowRight className="h-3.5 w-3.5 text-primary" />
                    </span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="mx-auto max-w-5xl px-4 py-16 text-center sm:px-6 sm:py-24">
        <h2 className="mb-4 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
          Zainwestuj w swój kanał
        </h2>
        <p className="mx-auto mb-10 max-w-xl text-muted-foreground">
          Jednorazowa płatność – bez subskrypcji, bez ukrytych kosztów.
        </p>
        <Card className="mx-auto max-w-md border-primary/20 p-8 shadow-lg">
          <p className="mb-1 text-sm font-medium uppercase tracking-wider text-muted-foreground">
            Pakiet kompletny
          </p>
          <div className="mb-2 flex items-baseline justify-center gap-1">
            <span className="text-5xl font-bold text-foreground">49</span>
            <span className="text-xl font-semibold text-muted-foreground">zł</span>
          </div>
          <p className="mb-6 text-sm text-muted-foreground">75 000 pomysłów · Natychmiastowy dostęp</p>
          <Button size="lg" className="w-full gap-2 text-base font-semibold shadow-lg shadow-primary/25" asChild>
            <a href={PAYPAL_LINK}>
              Kup teraz
              <ArrowRight className="h-4 w-4" />
            </a>
          </Button>
          <p className="mt-4 text-xs text-muted-foreground">Bezpieczna płatność przez PayPal</p>
        </Card>
      </section>

      {/* FAQ */}
      <section className="bg-secondary/40 py-16 sm:py-24">
        <div className="mx-auto max-w-2xl px-4 sm:px-6">
          <h2 className="mb-10 text-center text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Często zadawane pytania
          </h2>
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, i) => (
              <AccordionItem key={i} value={`faq-${i}`}>
                <AccordionTrigger className="text-left text-foreground">{faq.q}</AccordionTrigger>
                <AccordionContent className="text-muted-foreground">{faq.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="mx-auto max-w-5xl px-4 text-center sm:px-6">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} · 75 000 pomysłów na YouTube Shorts
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
