import { CheckCircle, Download } from "lucide-react";
import { Button } from "@/components/ui/button";

const ThankYou = () => {
  return (
    <main className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="mx-auto max-w-lg text-center">
        <div className="mb-6 inline-flex h-20 w-20 items-center justify-center rounded-full bg-primary/10">
          <CheckCircle className="h-10 w-10 text-primary" />
        </div>
        <h1 className="mb-4 text-4xl font-bold tracking-tight text-foreground">
          Dziękujemy za zakup!
        </h1>
        <p className="mb-8 text-lg text-muted-foreground">
          Twoja płatność została zrealizowana pomyślnie. Kliknij poniżej, aby pobrać swój pakiet
          <strong className="text-foreground"> 75 000 pomysłów na YouTube Shorts</strong>.
        </p>
        <Button size="lg" className="gap-2 px-8 text-base font-semibold" asChild>
          <a href="https://example.com/download" target="_blank" rel="noopener noreferrer">
            <Download className="h-5 w-5" />
            Pobierz produkt
          </a>
        </Button>
        <p className="mt-6 text-sm text-muted-foreground">
          Jeśli masz pytania, napisz do nas na{" "}
          <a href="mailto:monsterfrank669@gmail.com" className="text-primary underline">
            monsterfrank669@gmail.com
          </a>
        </p>
      </div>
    </main>
  );
};

export default ThankYou;
